﻿//Дає змогу передавати запити послідовно ланцюжком обробників
using System;

abstract class Handler
{
    protected Handler NextHandler; //В класі Handler є змінна NextHandler, яка зберігає об'єкт типу Handler

    //Метод для встановлення наступногообробника
    public void SetNext(Handler handler)  => NextHandler = handler;
    public abstract void HandleRequest(int request);
}

//Конкретний обробник 1
class ConcreteHandler1 : Handler
{
    public override void HandleRequest(int request)
    {
        if (request < 10)
            Console.WriteLine($"ConcreteHandler1 обробив запит {request}");
        else
            NextHandler?.HandleRequest(request); //Передаємо далі, якщо є наступний обробник
    }
}

//Конкретний обробник 2
class ConcreteHandler2 : Handler
{
    public override void HandleRequest(int request)
    {
        if (request >= 10 && request < 20)
            Console.WriteLine($"ConcreteHandler2 обробив запит {request}");
        else
            NextHandler?.HandleRequest(request); //Передаємо далі
    }
}

class Program
{
    static void Main()
    {
        //Створення обробників
        Handler h1 = new ConcreteHandler1();
        Handler h2 = new ConcreteHandler2();

        h1.SetNext(h2); //Зв'язуємо обробники в ланцюг

        //Обробка ConcreteHandler1/2 
        h1.HandleRequest(5);
        h1.HandleRequest(15);
    }
}
