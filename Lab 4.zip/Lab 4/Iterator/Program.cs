﻿//Дає змогу послідовно обходити елементи складових об’єктів, не розкриваючи їхньої внутрішньої організації
using System;
using System.Collections;
using System.Collections.Generic;

//Узагальнена колекція, яка підтримує ітерацію
class CustomCollection<T> : IEnumerable<T>
{
    private List<T> _items = new List<T>(); //Список елементів

    public void Add(T item) => _items.Add(item); //Додаємо елементи до списку

    public IEnumerator<T> GetEnumerator() => _items.GetEnumerator(); //Повертає ітератор, який дозволяє проходити по елементах колекції

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator(); //Необхідно для підтримки неузагальненого ітератора(він працює без вказання конкретного типу (T))
}

class Program
{
    static void Main()
    {
        CustomCollection<int> collection = new CustomCollection<int>(); //Створюємо колекцію
        collection.Add(1);
        collection.Add(2);
        collection.Add(3);

        foreach (var item in collection)
            Console.WriteLine(item);
    }
}
