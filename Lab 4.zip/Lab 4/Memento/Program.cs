﻿//Дає змогу зберігати та відновлювати минулий стан об’єктів, не розкриваючи подробиць їхньої реалізації
using System;
using System.Collections.Generic;

//Клас, що зберігає стан об'єкта
class Memento
{
    public string State { get; private set; }

    public Memento(string state) => State = state; //Конструктор для встановлення стану
}

//Клас, стан якого зберігається
class Originator
{
    public string State { get; set; } //Поточний стан

    public Memento SaveState() => new Memento(State);

    public void RestoreState(Memento memento) => State = memento.State;
}

//Клас, що управляє збереженням та відновленням стану
class Caretaker
{
    private Stack<Memento> _history = new Stack<Memento>(); //Історія станів

    public void Save(Originator originator) => _history.Push(originator.SaveState());

    public void Undo(Originator originator)
    {
        if (_history.Count > 0)
            originator.RestoreState(_history.Pop());
    }
}

class Program
{
    static void Main()
    {
        //Originator зберігає стан, а Caretaker дозволяє його відновлювати
        Originator originator = new Originator();
        Caretaker caretaker = new Caretaker();

        //Зберігаємо стани
        originator.State = "Стан 1";
        caretaker.Save(originator); 

        originator.State = "Стан 2";
        caretaker.Save(originator);

        originator.State = "Стан 3";
        Console.WriteLine($"Поточний стан: {originator.State}");

        // Відкати
        caretaker.Undo(originator);
        Console.WriteLine($"Відновлений стан: {originator.State}");

        caretaker.Undo(originator);
        Console.WriteLine($"Відновлений стан: {originator.State}");
    }
}
