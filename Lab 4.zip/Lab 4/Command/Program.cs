﻿//Перетворює запити на об’єкти
using System;
interface ICommand
{
    void Execute();
}

//Клас, який отримує команди
class Light
{
    public void TurnOn() => Console.WriteLine("Світло увімкнено");
    public void TurnOff() => Console.WriteLine("Світло вимкнено");
}

class TurnOnCommand : ICommand
{
    private Light _light; //Оголошуємо змінну _light типу Light, яка буде зберігати посилання на об'єкт, що виконуватиме команду

    public TurnOnCommand(Light light) => _light = light; //Передаємо об'єкт світла

    public void Execute() => _light.TurnOn();
}

class TurnOffCommand : ICommand
{
    private Light _light;

    public TurnOffCommand(Light light) => _light = light;

    public void Execute() => _light.TurnOff();
}

//Пульт керування
class RemoteControl
{
    private ICommand _command; //Поточна команда

    public void SetCommand(ICommand command) => _command = command;

    public void PressButton() => _command.Execute();
}

class Program
{
    static void Main()
    {
        // Створюємо приймач і пульт
        Light light = new Light();
        RemoteControl remote = new RemoteControl();

        remote.SetCommand(new TurnOnCommand(light));
        remote.PressButton(); 

        remote.SetCommand(new TurnOffCommand(light)); 
        remote.PressButton(); 
    }
}
