﻿//Створює механізм підписки, що дає змогу одним об’єктам стежити й реагувати на події, які відбуваються в інших об’єктах
using System;
using System.Collections.Generic;

interface IObserver
{
    void Update(string message);
}

//Клас, що є спостережуваним
class Subject
{
    private List<IObserver> _observers = new List<IObserver>();

    public void Attach(IObserver observer) => _observers.Add(observer); 

    public void Detach(IObserver observer) => _observers.Remove(observer); 

    public void Notify(string message)
    {
        foreach (var observer in _observers)
            observer.Update(message);
    }
}

//Конкретний підписник
class ConcreteObserver : IObserver
{
    private string _name;

    public ConcreteObserver(string name) => _name = name;

    public void Update(string message) => Console.WriteLine($"{_name} отримав повідомлення: {message}");
}

class Program
{
    static void Main()
    {
        Subject subject = new Subject();

        ConcreteObserver observer1 = new ConcreteObserver("Спостерігач 1");
        ConcreteObserver observer2 = new ConcreteObserver("Спостерігач 2");

        subject.Attach(observer1);
        subject.Attach(observer2);

        subject.Notify("Дані оновлено!"); //Сповіщає всіх підписників
    }
}
