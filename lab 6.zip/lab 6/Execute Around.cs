﻿//Обгортає виконання певної операції додатковими діями до та після її виконання
using System;

public class ExecuteAroundExample
{
    public delegate void Operation();

    public static void ExecuteWithWrapper(Operation operation)
    {
        Console.WriteLine("Before operation");
        operation();
        Console.WriteLine("After operation");
    }

    public static void Main()
    {
        //Створення лямбда-виразу для операції
        Operation myOperation = () => Console.WriteLine("Executing operation");

        ExecuteWithWrapper(myOperation); // Виведе: Before, Executing, After
    }
}
