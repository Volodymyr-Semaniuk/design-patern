﻿//Делегує створення об'єктів окремим методам або класам, а не створює їх напряму через new
using System;

public class FactoryMethodExample
{
    public interface IProduct
    {
        void Operate();
    }

    public class ProductA : IProduct
    {
        public void Operate() => Console.WriteLine("Product A operation");
    }

    public class ProductB : IProduct
    {
        public void Operate() => Console.WriteLine("Product B operation");
    }

    //Делегат, який представляє метод створення продукту
    public delegate IProduct FactoryMethod();

    //Фабричні методи для створення продуктів A,В
    public static IProduct CreateProductA() => new ProductA();
    public static IProduct CreateProductB() => new ProductB();

    public static void Main()
    {
        //Призначаємо фабричний метод для продукту A делегату
        FactoryMethod factoryA = CreateProductA;
        IProduct productA = factoryA();      //Створюємо продукт A
        productA.Operate();                  //Виведе: Product A operation

        FactoryMethod factoryB = CreateProductB;
        IProduct productB = factoryB();     
        productB.Operate();     
    }
}
