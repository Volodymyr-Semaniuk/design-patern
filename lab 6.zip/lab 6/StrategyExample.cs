﻿//Дозволяє змінювати поведінку об'єкта під час виконання програми, обираючи одну з кількох можливих реалізацій алгоритму
using System;

public class StrategyExample
{
    public delegate int Strategy(int a, int b);
    
    //Стратегії
    public static int Add(int a, int b) => a + b;
    public static int Multiply(int a, int b) => a * b;

    public static void Main()
    {
        Strategy strategy = Add;
        Console.WriteLine(strategy(5, 3)); 

        strategy = Multiply;
        Console.WriteLine(strategy(5, 3));
    }
}
