﻿//Дозволяє динамічно додавати нову функціональність до об'єкта без зміни його коду
public class DecoratorExample
{
    public delegate string TextDecorator(string text);

    //Визначає метод BasicText, який приймає рядок і повертає його без змін
    public static string BasicText(string text) => text;

    public static string AddExclamation(string text) => text + "!";

    public static string AddQuestionMark(string text) => text + "?";

    public static void Main()
    {
        //Делегат, що буде використовувати базову функцію
        TextDecorator decorator = BasicText;

        Console.WriteLine(decorator("Hello"));

        decorator = AddExclamation;
        Console.WriteLine(decorator("Hello"));

        decorator = AddQuestionMark;
        Console.WriteLine(decorator("Hello"));
    }
}
