﻿namespace Solid_Violation_Examples.ISP
{
    public class Bird : IFlyable, IRunable
    {
        public void Run() => Console.WriteLine("Bird is running");
        public void Fly() => Console.WriteLine("Bird is flying");
    }
}
