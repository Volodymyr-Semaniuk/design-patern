﻿namespace Solid_Violation_Examples.ISP
{
    // Розбиття інтерфейсу IAnimal на менші інтерфейси, кожен з яких відповідає конкретним здібностям
    public interface IRunable
    {
        void Run();
    }

    public interface IBarkable
    {
        void Bark();
    }

    public interface IFlyable
    {
        void Fly();
    }
}
