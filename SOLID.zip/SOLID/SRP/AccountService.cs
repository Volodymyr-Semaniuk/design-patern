﻿using System.Globalization;
using System.Transactions;

namespace Solid_Violation_Examples.SRP
{
    public class AccountService
    {
        private readonly ITransactionRepository _transactionRepository;
        private readonly Clock _clock;
        private readonly ConsolePrinter _console;
        private readonly StatementPrinter _statementPrinter; // ✅ Виділили окремий клас для друку виписки

        public AccountService(ITransactionRepository transactionRepository, Clock clock, ConsolePrinter console, StatementPrinter statementPrinter)
        {
            _transactionRepository = transactionRepository;
            _clock = clock;
            _console = console;
            _statementPrinter = statementPrinter;
        }

        public void Deposit(int amount) => _transactionRepository.Add(TransactionWith(amount));

        public void Withdraw(int amount) => _transactionRepository.Add(TransactionWith(-amount));

        public void PrintStatement()
        {
            List<Transaction> transactions = _transactionRepository.GetAll();
            _statementPrinter.Print(transactions); // ✅ Передаємо список транзакцій у StatementPrinter
        }

        private Transaction TransactionWith(int amount) => new Transaction(_clock.Today, amount);
    }
}
