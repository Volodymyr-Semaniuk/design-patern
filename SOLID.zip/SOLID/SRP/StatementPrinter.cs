﻿using System.Globalization;

namespace Solid_Violation_Examples.SRP
{
    public class StatementPrinter
    {
        private const string STATEMENT_HEADER = "DATE | AMOUNT | BALANCE";
        private const string DATE_FORMAT = "dd/MM/yyyy";
        private const string AMOUNT_FORMAT = "F2";

        private readonly ConsolePrinter _console;

        public StatementPrinter(ConsolePrinter console)
        {
            _console = console;
        }

        public void Print(List<Transaction> transactions)
        {
            PrintHeader();
            PrintTransactions(transactions);
        }

        private void PrintHeader() => _console.PrintLine(STATEMENT_HEADER);

        private void PrintTransactions(List<Transaction> transactions)
        {
            int balance = 0;
            foreach (var transaction in transactions.OrderByDescending(t => t.Date))
            {
                balance += transaction.Amount;
                _console.PrintLine(StatementLine(transaction, balance));
            }
        }

        private string StatementLine(Transaction transaction, int balance) =>
            $"{FormatDate(transaction.Date)} | {FormatNumber(transaction.Amount)} | {FormatNumber(balance)}";

        private string FormatDate(DateOnly date) =>
            date.ToString(DATE_FORMAT, CultureInfo.InvariantCulture);

        private string FormatNumber(int amount) =>
            amount.ToString(AMOUNT_FORMAT, CultureInfo.InvariantCulture);
    }
}
