﻿namespace Solid_Violation_Examples.SRP
{
    public class Clock
    {
        public DateOnly Today => DateOnly.FromDateTime(DateTime.Today);
    }
}
