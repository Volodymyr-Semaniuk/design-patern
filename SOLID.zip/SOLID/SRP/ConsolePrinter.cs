﻿namespace Solid_Violation_Examples.SRP
{
    public class ConsolePrinter
    {
        public void PrintLine(string line) => Console.WriteLine(line);
    }
}
