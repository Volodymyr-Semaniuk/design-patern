﻿namespace Solid_Violation_Examples.DIP
{
    // Інтерфейс для класу Clock
    public interface IClock
    {
        DateOnly MonthDay();
    }

    public class Clock : IClock
    {
        public DateOnly MonthDay()
        {
            var today = DateOnly.FromDateTime(DateTime.Today);
            return new DateOnly(1, today.Month, today.Day);
        }
    }
}
