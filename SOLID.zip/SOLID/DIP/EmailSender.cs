﻿namespace Solid_Violation_Examples.DIP
{
    // Створюємо інтерфейс для відправки email
    public interface IEmailSender
    {
        void Send(Email email);
    }

    public class EmailSender : IEmailSender
    {
        public void Send(Email email) =>
            Console.WriteLine($"To: {email.To}, Subject: {email.Subject}, Message: {email.Message}");
    }
}
