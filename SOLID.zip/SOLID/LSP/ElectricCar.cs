﻿namespace Solid_Violation_Examples.LSP
{
    public class ElectricCar : ElectricVehicle // Тепер наслідує ElectricVehicle
    {
        private const int BATTERY_FULL = 100;
        public int BatteryLevel { get; private set; }

        public override void ChargeBattery() => BatteryLevel = BATTERY_FULL;

        // Видалено метод FillUpWithFuel(), бо електромобілі не заправляються бензином
    }
}
