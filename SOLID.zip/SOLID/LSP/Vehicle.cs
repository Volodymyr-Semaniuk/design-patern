﻿namespace Solid_Violation_Examples.LSP
{
    // Базовий клас для всіх транспортних засобів
    public abstract class Vehicle
    {
        private bool _engineStarted = false;

        public void StartEngine() => _engineStarted = true;
        public void StopEngine() => _engineStarted = false;
        public bool IsEngineStarted() => _engineStarted;
    }

    // Виділено окремий клас для паливних авто
    public abstract class FuelVehicle : Vehicle
    {
        public abstract void FillUpWithFuel();
    }

    // Виділено окремий клас для електромобілів
    public abstract class ElectricVehicle : Vehicle
    {
        public abstract void ChargeBattery();
    }
}
