﻿namespace Solid_Violation_Examples.OCP
{
    // Базовий клас для всіх співробітників
    public abstract class Employee
    {
        protected int Salary { get; }

        protected Employee(int salary)
        {
            Salary = salary;
        }

        // Абстрактний метод для розрахунку зарплати, який реалізується в підкласах
        public abstract int PayAmount();
    }

    // Інженер отримує тільки базову зарплату
    public class Engineer : Employee
    {
        public Engineer(int salary) : base(salary) { }

        public override int PayAmount() => Salary;
    }

    // Менеджер отримує базову зарплату + бонус
    public class Manager : Employee
    {
        private int _bonus;

        public Manager(int salary, int bonus) : base(salary)
        {
            _bonus = bonus;
        }

        public override int PayAmount() => Salary + _bonus;
    }
}
